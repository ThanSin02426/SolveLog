import { INDEX_PATH } from "../shared/constants.js";
import { classifyProblem } from "../shared/classifier.js";
import {
  buildCommitMessage,
  buildMetadata,
  buildProblemGeneratedBlock,
  buildRootReadme,
  createRecord,
  mergeProblemReadme,
  problemDirectory,
  solutionFilename,
  updateRecordLanguage
} from "../shared/generators.js";
import { normaliseSubmission } from "../shared/submission-model.js";
import {
  assertNonEmptyString,
  isoNow,
  normalizeDifficulty,
  safeJsonParse,
  slugify
} from "../shared/utils.js";
import {
  GitHubClient,
  isNoChangesCommitError,
  isRepositoryRace,
  retryDelay
} from "./github-client.js";

const MAX_SYNC_ATTEMPTS = 6;

function validateSubmission(raw) {
  const submission = normaliseSubmission(raw);
  const problem = {
    platform: submission.platform,
    frontendId: String(submission.problem.id || submission.problem.slug).trim(),
    title: String(submission.problem.title || "").trim(),
    slug: slugify(submission.problem.slug || submission.problem.title),
    difficulty: normalizeDifficulty(submission.problem.difficulty),
    tags: Array.isArray(submission.problem.tags) ? submission.problem.tags.map(String).slice(0, 40) : [],
    language: String(submission.solution.language || "").trim().toLowerCase(),
    code: String(submission.solution.code || ""),
    runtime: String(submission.solution.runtime || "").slice(0, 80),
    memory: String(submission.solution.memory || "").slice(0, 80),
    submissionId: String(submission.platformSubmissionId || "manual").slice(0, 120),
    solvedAt: submission.solvedAt || isoNow(),
    url: safeProblemUrl(submission.problem.url, submission.platform, submission.problem.slug),
    syncSource: submission.syncSource,
    context: submission.context
  };

  assertNonEmptyString(problem.frontendId, "Problem number", 80);
  assertNonEmptyString(problem.title, "Problem title", 300);
  assertNonEmptyString(problem.slug, "Problem slug", 300);
  assertNonEmptyString(problem.language, "Language", 80);
  assertNonEmptyString(problem.code, "Solution code", 500_000);
  return problem;
}

function emptyIndex() {
  return { schemaVersion: 2, generatedAt: isoNow(), problems: [] };
}

async function prepareAgainstSnapshot(problem, client, headSha) {
  const indexFile = await client.getFile(INDEX_PATH, headSha);
  const index = indexFile ? safeJsonParse(indexFile.text, emptyIndex()) : emptyIndex();
  if (!Array.isArray(index.problems)) index.problems = [];
  index.schemaVersion = 2;

  let record = index.problems.find((item) =>
    String(item.platform || "leetcode") === problem.platform && item.slug === problem.slug
  );
  const isNewProblem = !record;
  const classification = record
    ? { primaryDomain: record.primaryDomain, secondaryDomains: record.secondaryDomains || [] }
    : classifyProblem(problem.tags);

  if (!record) {
    const path = problemDirectory(problem, classification);
    record = createRecord(problem, classification, path);
    index.problems.push(record);
  }

  const isDuplicate = Object.values(record.languages || {}).some(
    (entry) => String(entry.latestSubmissionId) === problem.submissionId && problem.submissionId !== "manual"
  );
  if (isDuplicate) {
    return { duplicate: true, problem, record, index, classification, isNewProblem };
  }

  const existingSolution = await client.getFile(`${record.path}/${solutionFilename(problem.language)}`, headSha);
  if (existingSolution?.text?.trimEnd() === problem.code.trimEnd() && problem.submissionId !== "manual") {
    return { duplicate: true, problem, record, index, classification, isNewProblem };
  }

  updateRecordLanguage(record, problem);
  record.platform = problem.platform;
  record.tags = problem.tags;
  record.difficulty = problem.difficulty;
  record.url = problem.url;
  index.generatedAt = isoNow();

  const existingReadme = await client.getFile(`${record.path}/README.md`, headSha);
  const generated = buildProblemGeneratedBlock(problem, record);
  const problemReadme = mergeProblemReadme(existingReadme?.text || "", generated);

  const files = [
    { path: `${record.path}/${solutionFilename(problem.language)}`, content: `${problem.code.trimEnd()}\n` },
    { path: `${record.path}/metadata.json`, content: buildMetadata(problem, record) },
    { path: `${record.path}/README.md`, content: `${problemReadme.trimEnd()}\n` },
    { path: INDEX_PATH, content: `${JSON.stringify(index, null, 2)}\n` },
    { path: "README.md", content: buildRootReadme(index) }
  ];

  return { duplicate: false, problem, record, index, classification, isNewProblem, files };
}

export async function syncToGitHub(rawSubmission, settings) {
  const problem = validateSubmission(rawSubmission);
  const client = new GitHubClient(settings);

  await client.initializeIfEmpty(buildRootReadme(emptyIndex()));

  let lastRace = null;
  for (let attempt = 0; attempt < MAX_SYNC_ATTEMPTS; attempt += 1) {
    const head = await client.getHead();
    const prepared = await prepareAgainstSnapshot(problem, client, head.sha);

    if (prepared.duplicate) {
      return {
        duplicate: true,
        problem,
        record: prepared.record,
        commitUrl: null,
        stats: calculateStats(prepared.index)
      };
    }

    try {
      const commit = await client.commitFilesAtHead(
        prepared.files,
        buildCommitMessage(problem, prepared.classification, prepared.isNewProblem),
        head
      );

      return {
        duplicate: false,
        problem,
        record: prepared.record,
        commitUrl: `https://github.com/${settings.owner}/${settings.repo}/commit/${commit.sha}`,
        stats: calculateStats(prepared.index)
      };
    } catch (error) {
      if (isNoChangesCommitError(error)) {
        return {
          duplicate: true,
          problem,
          record: prepared.record,
          commitUrl: null,
          stats: calculateStats(prepared.index)
        };
      }
      if (!isRepositoryRace(error)) throw error;
      lastRace = error;
      if (attempt < MAX_SYNC_ATTEMPTS - 1) await retryDelay(attempt);
    }
  }

  if (lastRace) {
    lastRace.attempts = MAX_SYNC_ATTEMPTS;
    lastRace.repeated = true;
    throw lastRace;
  }
  throw new Error("SolveLog could not create the GitHub commit.");
}

export function calculateStats(index) {
  const stats = { total: 0, Easy: 0, Medium: 0, Hard: 0 };
  for (const problem of index.problems || []) {
    stats.total += 1;
    if (Object.hasOwn(stats, problem.difficulty)) stats[problem.difficulty] += 1;
  }
  return stats;
}

export function normalizeForExport(rawSubmission) {
  return validateSubmission(rawSubmission);
}

function safeProblemUrl(value, platform, slug) {
  const fallback = platform === "leetcode" && slug
    ? `https://leetcode.com/problems/${slug}/`
    : "";
  try {
    const url = new URL(value || fallback);
    if (url.protocol !== "https:") return fallback;
    return url.href;
  } catch {
    return fallback;
  }
}
